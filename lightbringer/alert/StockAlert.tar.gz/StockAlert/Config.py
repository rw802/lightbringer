format = 'pandas'
APIKey = 'ZVY8JAUULWG4TEFT'
# gAPIKey = 'XW8FNJQ9TOIU2LOR'
interval60 = '60min'
interval5 = '5min'
intervalDaily = 'daily'

timeInterval60min = 60*20; # 20 minutes
timeInterval5min = 60*3; # 2 minutes
