from slackclient import SlackClient

class Message():
    def __init__(self):
        slack_token = 'xoxp-257787694487-256522599297-271103305072-997e95878b04cf715b010d45af2abe79'
        self.slack = SlackClient(slack_token)
        
    def sendSlack(self, msg):
        msg = ':o:\n'+msg+'\n:tada:'
        self.slack.api_call(
          "chat.postMessage",
          channel="alert-bot",
          username='ALERTBOT',
          text=msg,
          icon_emoji=':ninja:'
        )