from IntraDay import IntraDay
import Config as cfg
from alpha_vantage.timeseries import TimeSeries
from alpha_vantage.techindicators import TechIndicators

inputPath = '/code/stock/scan/ScanIn5Min.txt'
ti = TechIndicators(key=cfg.APIKey, output_format=cfg.format)
ts = TimeSeries(key=cfg.APIKey, output_format=cfg.format)
inqueryInterval = cfg.interval5
schedulerInterval = 2

intraDayFiveMin = IntraDay(
    symbolFilePath = inputPath, 
    avTimeSeriesObj=ts, 
    avTechIndicatorObj=ti, 
    inqueryInterval=inqueryInterval, 
    schedulerInterval=schedulerInterval
    )

intraDayFiveMin.run(CandleMustBull = True)