import datetime
from Util import *
from Message import Message
import sched, time
from Symbol import Symbol

now = datetime.datetime.now()    
time3pm = now.replace(hour=23, minute=0, second=0, microsecond=0) 

class IntraDay:
    
    def checkSymbol(self, MAMustBull = False, CandleMustBull = False, MACDMustBull = False, RSIMustBull = False, BBandMustBull = False):
        now = datetime.datetime.now()
        if now > time3pm:
            print 'market close'
            return
        for symbol in self.symbolList:
            symbol = symbol.rstrip()
            print self.inqueryInterval + ' checking #' + symbol + '\n'
            
            symbolObj = Symbol(symbol, self.inqueryInterval, self.avTimeSeriesObj, self.avTechIndicatorObj)
            try:
                bullish, flag, text, rate = symbolObj.rate(CandleMustBull=True)
            except:
                continue  
        
            if bullish:
                self.msg.sendSlack(text)
                
                   
        self.scheduler.enter(self.schedulerInterval, 1, self.checkSymbol, 
                             (
                                 MAMustBull, 
                                 CandleMustBull, 
                                 MACDMustBull, 
                                 RSIMustBull, 
                                 BBandMustBull
                                 )
                             )
        pass
    
    def run(self, MAMustBull = False, CandleMustBull = False, MACDMustBull = False, RSIMustBull = False, BBandMustBull = False):
        self.scheduler.enter(self.schedulerInterval, 1, self.checkSymbol, 
                             (
                                 MAMustBull, 
                                 CandleMustBull, 
                                 MACDMustBull, 
                                 RSIMustBull, 
                                 BBandMustBull
                                 )
                             )
        self.scheduler.run()
    
    def __init__(self, symbolFilePath, avTimeSeriesObj, avTechIndicatorObj, inqueryInterval, schedulerInterval):
        self.path = symbolFilePath
        self.inqueryInterval = inqueryInterval
        self.scheduler = sched.scheduler(time.time, time.sleep)
        self.msg = Message()
        self.avTimeSeriesObj = avTimeSeriesObj
        self.avTechIndicatorObj = avTechIndicatorObj
        self.schedulerInterval = schedulerInterval
        self.symbolList = list(set(readIntoList(symbolFilePath)))

